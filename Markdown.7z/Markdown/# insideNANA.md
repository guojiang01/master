# Inside NAND Flash Memory

1. Flash memory 
   1. NOR : random access. access time : Random:60-120ns,page mode/burst mode: 30ns/15ns. write speed: random : 10$\mu s$/byte or word .
   2. NAND : serial access. access speed: Random: 10-50$\mu s$, serial(page mode): 25-50ns. write speed : random: $200\mu s $/byte, page:$200\mu s$/page(0.4$\mu s$/byte)